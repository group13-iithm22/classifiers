# the code is party based on: http://jonathansoma.com/lede/algorithms-2017/classes/more-text-analysis/nrc-emotional-lexicon/
# the emotion lexicon used can be downloaded here: https://saifmohammad.com/WebPages/NRC-Emotion-Lexicon.htm

import spacy
import pandas as pd
import csv
from collections import Counter
nlp = spacy.load("en_core_web_sm")

NRCpolarity = ["positive", "negative"]
emotionset = NRCpolarity
filename = "your_polarity_input.tsv"
outputfilename = "your_NRCpol_output.tsv"
detailed_outputfile = "your_NRCpol_overview.txt"
f_out = open(detailed_outputfile, "w+")
filepath = "NRCemo_lexicon.txt"
emolex_df = pd.read_csv(filepath, names=["word", "emotion", "association"],  sep="\t")

def preprocess_token(token):
    # OPTIONS: token.text, token.lemma_, token.pos_, token.tag_, token.dep_,token.shape_, token.is_alpha, token.is_stop
    key = token.text
    return(key)

def analyze_line(s, emotionset):
    emoCounter = Counter()
    for e in emotionset:
        emoCounter[e] = 0
    for token in s:
        key = preprocess_token(token)
        word_df = emolex_df[emolex_df.word == key]
        for index, row in word_df.iterrows():
            if row["emotion"] in emotionset:
                emoCounter[row["emotion"]] += int(row["association"])
    return(emoCounter)

def aggregate_polarity(emoCounter):
    # polarity value: number of positive words - number of negative words
    # if result = 0 or no positive or negative word is found  => polarity value = neutral
    polarity = "neutral"
    if (emoCounter["positive"] - emoCounter["negative"]) > 0:
        polarity = "positive"
    elif (emoCounter["positive"] - emoCounter["negative"]) < 0:
        polarity = "negative"
    return(polarity)

def main():
    aggrEmoCounter = Counter()
    for e in emotionset:
        aggrEmoCounter[e] = 0
    with open(outputfilename, "w", newline="") as file:
        writer = csv.writer(file, delimiter="\t")
        writer.writerow(["ID", "Gold", "Pred", "Text"])
        f_out.write("ID\tPred\tdetails\n")
        with open(filename, newline="") as tsvfile:
            reader = csv.reader(tsvfile, delimiter="\t")
            next(reader)
            for row in reader:
                s = nlp(row[2])
                emoCounter = analyze_line(s, emotionset)
                if len(emotionset) == 2 and "positive" in emotionset and "negative" in emotionset:
                    main_result = aggregate_polarity(emoCounter)
                else:
                    main_result = aggregate_emotions(emoCounter)
                writer.writerow([row[0], row[1], main_result, row[2]])
                f_out.write(row[0] + "\t" + main_result + "\t" + str(emoCounter) + "\n")
                aggrEmoCounter[main_result] += 1
    print("emotion set:\t", emotionset, "\nglobal stats:\t", aggrEmoCounter, "\nunits analysed:\t", sum(aggrEmoCounter.values()))

if __name__ == "__main__": main()