from nltk.sentiment.vader import SentimentIntensityAnalyzer
import csv
import spacy
nlp=spacy.load("en_core_web_sm")

analyzer = SentimentIntensityAnalyzer()
filename = "your_polarity_input.tsv"
outputfilename = "your_VADER_output_lemma.tsv"
outputfile = "your_VADER_overview_lemma.txt"
f_out = open(outputfile, "w+")

def preprocess_token(token):
    ## OPTIONS: token.text, token.lemma_, token.pos_, token.tag_, token.dep_,token.shape_, token.is_alpha, token.is_stop
    key = token.lemma_
    return(key)

def sentence_doc():
    with open(outputfilename, "w", newline="") as file:
        writer = csv.writer(file, delimiter="\t")
        writer.writerow(["ID", "Gold", "Pred", "Text"])
        f_out.write("ID\tPred\tdetails\n")
        with open(filename, newline="") as csvfile:
            reader = csv.reader(csvfile, delimiter="\t")
            next(reader)
            for row in reader:
                sentence = row[2]
                doc = nlp(sentence)
                s = ""
                for token in doc:
                    s = s + " " + preprocess_token(token)
                ss = analyzer.polarity_scores(s)
                pred_value = ""
                for i in ss:
                    if i == "compound":
                        if ss[i] > 0:
                            pred_value = "positive"
                        elif ss[i] < 0:
                            pred_value = "negative"
                        else:
                            pred_value = "neutral"
                f_out.write(row[0] + "\t" + pred_value + "\t" + str(ss) + "\n")
                writer.writerow([row[0], row[1], pred_value,row[2]])
                print(s)

def main():
    sentence_doc()

if __name__ == "__main__": main()