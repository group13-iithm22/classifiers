import csv
from sklearn.model_selection import cross_validate
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
inputfile = "your_VADER_output_lemma.tsv"
outputfile = "your_VADER_evaluation_report_lemma.txt"
f_out = open(outputfile, "w+")

y_true=[]
y_pred=[]

with open(inputfile, newline="") as csvfile:
    reader = csv.reader(csvfile, delimiter="\t")
    next(reader)
    for row in reader:
        y_true.append(row[1])
        y_pred.append(row[2])
    f_out.write("VADER Polarity Evaluation Report: Lemmas\n")
    f_out.write("\ngold:\t" + str([[x, y_true.count(x)] for x in set(y_true)]))
    f_out.write("\npred:\t" + str([[x, y_pred.count(x)] for x in set(y_pred)]))

f_out.write("\n\ninput: " + inputfile)
f_out.write("\n\naccuracy_score: " + str(accuracy_score(y_true, y_pred)))
f_out.write("\n\nclassification report:\n\n" + classification_report(y_true, y_pred))
f_out.write("\n\nconfusion matrix:\n" + "row is gold  /  column is predicted" + "\n\n" + str(confusion_matrix(y_true, y_pred)))